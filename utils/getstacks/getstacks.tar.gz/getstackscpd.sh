#!/bin/bash

scriptdir=`dirname "$0"`
gdbpackage="gdb-8.2.1-x86_64.tar.gz"
gdbpackageloc="${scriptdir}/${gdbpackage}"
instance=ds-px-default
pidsfile=pids.txt.stacks

if [ "$1" != "" ] ; then
  instance=$1
fi

cat > podstacks.sh <<EOF
ps -ef | grep "osh" | grep -v grep > ${pidsfile}
for pid in \$(ps -ef | grep "osh" | grep -v grep | awk '{print \$2}'); do
  type=\`cat ${pidsfile} | grep \$pid | head -1 | grep -v grep | awk '{print \$19}'\`
  if [ "\$type" != "ORCHESTRATE_Section_Leader" ] ; then
    opname=\`cat ${pidsfile} | grep \$pid | grep -v grep | awk '{print \$20}'\`
    filename=\$pid.\$type.\$opname.txt.stacks
  else
    filename=\$pid.\$type.txt.stacks
  fi
  echo "Dumping stack for osh \$pid to \$filename"
  ./gstack \$pid > \$filename
done
EOF

runtimebase="${instance}-ibm-datastage-px-runtime-"
runtimepods=`oc get pods | grep ${runtimebase} | awk '{print $1}'`

if [ "$runtimepods" = "" ] ; then
  echo "Runtime pods to update not found with prefix ${runtimebase}. Are you sure you are logged in?"
  exit
fi

echo "Gathering stacks from following runtime pods:"
echo "${runtimepods}"

for runtimepod in $runtimepods ; do
  echo "Copying ${gdbpackage} to ${runtimepod}"
  oc cp ${gdbpackageloc} ${runtimepod}:/tmp/${gdbpackage}
  echo "Copying podstacks.sh to ${runtimepod}"
  oc cp podstacks.sh ${runtimepod}:/tmp/podstacks.sh
  echo "Collecting stack traces"
  oc exec ${runtimepod} -- bash -c "cd /tmp && tar xfz ${gdbpackage} && chmod 755 podstacks.sh && ./podstacks.sh && tar cfz ${runtimepod}.stacks.tgz *.stacks"
  echo "Copying ${runtimepod}.stacks.tgz locally"
  oc cp ${runtimepod}:/tmp/${runtimepod}.stacks.tgz ${runtimepod}.stacks.tgz
done

computebase="${instance}-ibm-datastage-px-compute-"
computepods=`oc get pods | grep ${computebase} | awk '{print $1}'`

if [ "$computepods" = "" ] ; then
  echo "Compute pods to update not found with prefix ${computebase}. Are you sure you are logged in?"
  exit
fi

echo "Gathering stacks from following compute pods:"
echo "${computepods}"

for computepod in $computepods ; do
  echo "Copying ${gdbpackage} to ${computepod}"
  oc cp ${gdbpackageloc} ${computepod}:/tmp/${gdbpackage}
  echo "Copying podstacks.sh to ${computepod}"
  oc cp podstacks.sh ${computepod}:/tmp/podstacks.sh
  echo "Collecting stack traces"
  oc exec ${computepod} -- bash -c "cd /tmp && tar xfz ${gdbpackage} && chmod 755 podstacks.sh && ./podstacks.sh && tar cfz ${computepod}.stacks.tgz *.stacks"
  echo "Copying ${computepod}.stacks.tgz locally"
  oc cp ${computepod}:/tmp/${computepod}.stacks.tgz ${computepod}.stacks.tgz
done

echo "Done"
